# Database Team

Assuming you are using Visual Studio Code as your Code Editor, you need python 3 and above already installed on your machine

1.          python -m venv venv
2.          .\venv\Scripts\activate
3.          pip install -r requirements.txt
4.          python run.py

Step 3 is to install dependencies on your local machine.
Step 4 is used to run the command to the site in your browser.

Go to localhost:8080 in your web browser.
And the page should appear.
